import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, ShoppingCart } from 'lucide-react';

interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  image_url: string | null;
  status: string;
  created_at: string;
  categories: { name: string } | null;
  profiles: { username: string } | null;
}

const ProductDetail = () => {
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(false);
  const { id } = useParams();
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    if (id) {
      fetchProduct();
    }
  }, [id, user, navigate]);

  const fetchProduct = async () => {
    if (!id) return;

    const { data, error } = await supabase
      .from('products')
      .select(`
        id,
        title,
        description,
        price,
        image_url,
        status,
        created_at,
        categories(name),
        profiles(username)
      `)
      .eq('id', id)
      .single();

    if (!error && data) {
      setProduct(data);
    } else {
      toast({
        title: 'Error',
        description: 'Product not found',
        variant: 'destructive',
      });
      navigate('/');
    }
  };

  const addToCart = async () => {
    if (!user || !product) return;

    setLoading(true);

    const { error } = await supabase
      .from('cart_items')
      .upsert({
        user_id: user.id,
        product_id: product.id,
        quantity: 1
      }, {
        onConflict: 'user_id,product_id'
      });

    if (error) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'Success',
        description: 'Product added to cart!',
      });
    }

    setLoading(false);
  };

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="container mx-auto max-w-6xl">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-3xl font-bold">Product Details</h1>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Product Image */}
          <Card>
            <CardContent className="p-6">
              <div className="aspect-square bg-muted rounded-lg flex items-center justify-center">
                {product.image_url ? (
                  <img
                    src={product.image_url}
                    alt={product.title}
                    className="w-full h-full object-cover rounded-lg"
                  />
                ) : (
                  <span className="text-muted-foreground text-lg">No Image Available</span>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Product Info */}
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6 space-y-4">
                <div className="flex items-start justify-between">
                  <h1 className="text-3xl font-bold">{product.title}</h1>
                  {product.categories && (
                    <Badge variant="secondary" className="ml-4">
                      {product.categories.name}
                    </Badge>
                  )}
                </div>

                <div className="text-4xl font-bold text-primary">
                  ₹{product.price}
                </div>

                {product.description && (
                  <div>
                    <h3 className="font-semibold mb-2">Description</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {product.description}
                    </p>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4 py-4 border-t">
                  <div>
                    <span className="font-medium">Seller:</span>
                    <p className="text-muted-foreground">
                      {product.profiles?.username || 'Unknown Seller'}
                    </p>
                  </div>
                  <div>
                    <span className="font-medium">Listed:</span>
                    <p className="text-muted-foreground">
                      {new Date(product.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 pt-4">
                  <Button
                    onClick={addToCart}
                    disabled={loading || product.status !== 'active'}
                    className="flex-1 flex items-center gap-2"
                    size="lg"
                  >
                    <ShoppingCart className="h-4 w-4" />
                    {loading ? 'Adding...' : 'Add to Cart'}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => navigate('/cart')}
                    size="lg"
                  >
                    View Cart
                  </Button>
                </div>

                {product.status !== 'active' && (
                  <div className="bg-muted p-4 rounded-lg">
                    <p className="text-muted-foreground text-center">
                      This product is no longer available
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;