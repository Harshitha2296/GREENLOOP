import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { ArrowLeft } from 'lucide-react';

interface Purchase {
  id: string;
  amount: number;
  purchased_at: string;
  products: {
    id: string;
    title: string;
    image_url: string | null;
  };
  profiles: {
    username: string;
  } | null;
}

const Purchases = () => {
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    fetchPurchases();
  }, [user, navigate]);

  const fetchPurchases = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('purchases')
      .select(`
        id,
        amount,
        purchased_at,
        products (
          id,
          title,
          image_url
        ),
        profiles!purchases_seller_id_fkey (
          username
        )
      `)
      .eq('buyer_id', user.id)
      .order('purchased_at', { ascending: false });

    if (!error && data) {
      setPurchases(data);
    }
  };

  const totalSpent = purchases.reduce((sum, purchase) => sum + purchase.amount, 0);

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="container mx-auto max-w-4xl">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-3xl font-bold">My Purchases</h1>
        </div>

        {purchases.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-muted-foreground mb-4">No purchases yet</p>
              <Button onClick={() => navigate('/')}>Start Shopping</Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* Summary Card */}
            <Card>
              <CardHeader>
                <CardTitle>Purchase Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Purchases</p>
                    <p className="text-2xl font-bold">{purchases.length}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Total Spent</p>
                    <p className="text-2xl font-bold text-primary">₹{totalSpent.toFixed(2)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Purchases List */}
            <div className="space-y-4">
              {purchases.map((purchase) => (
                <Card key={purchase.id}>
                  <CardContent className="p-6">
                    <div className="flex gap-4">
                      <div className="w-20 h-20 bg-muted rounded-md flex-shrink-0">
                        {purchase.products.image_url ? (
                          <img
                            src={purchase.products.image_url}
                            alt={purchase.products.title}
                            className="w-full h-full object-cover rounded-md"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-muted-foreground text-xs">
                            No Image
                          </div>
                        )}
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-semibold text-lg mb-1">
                              {purchase.products.title}
                            </h3>
                            <p className="text-sm text-muted-foreground mb-2">
                              Sold by: {purchase.profiles?.username || 'Unknown Seller'}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Purchased on: {new Date(purchase.purchased_at).toLocaleDateString()}
                            </p>
                          </div>
                          
                          <div className="text-right">
                            <Badge variant="secondary" className="mb-2">
                              Completed
                            </Badge>
                            <p className="text-xl font-bold text-primary">
                              ₹{purchase.amount}
                            </p>
                          </div>
                        </div>
                        
                        <div className="mt-4">
                          <Button
                            variant="outline"
                            onClick={() => navigate(`/product/${purchase.products.id}`)}
                          >
                            View Product
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Purchases;